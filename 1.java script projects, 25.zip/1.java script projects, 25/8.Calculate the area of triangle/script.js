// Javascript program to find the area of the triangle
// General formula : (base*height/2);
// we will take the base and height measurment from the user and will calculate the area of the right angled triangle.

let base = prompt("enter the base of the triangle : ");
let height = prompt("enter the height of the triangle : ");
let area = base * height / 2;
console.log("the result is = ", area);
