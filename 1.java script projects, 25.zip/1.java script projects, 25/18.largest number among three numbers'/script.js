// javascript program to find largest number among three number

// using Math.max() method return the largerst number among the provided number
// syntax : Math.max(1,2,3);
// using user defined method
function check(p,q,r) {
   if(p >= q && p >= r) {
             return p;
   } else if(q >= p && q>=r) {
    return q;
   } else {
    return r;
   }
}

let a = prompt("please enter the first number : ");
let b = prompt("please enter the second number : ");
let c = prompt("please enter the third number : ");
let x = check(a,b,c);
console.log(a,b,c,' Largest =',x);

// using user defined method


