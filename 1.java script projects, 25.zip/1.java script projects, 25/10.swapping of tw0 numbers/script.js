// swapping using temp variable

let a = prompt("please enter the first value :");
let b = prompt("please enter the second value :");
console.log ('the value of a is = ',a);
console.log ("the value of b is = ", b);
let temp;
temp = a;
a = b;
b = temp;
console.log("after swapping of a = ", a);
console.log ("after swapping of b = ", b);

// without using temp variable

let x = parseInt(prompt("please enter the first value :"));
let y = parseInt(prompt("please enter the second value :"));
console.log ('the value of x is = ',x);
console.log ("the value of y is = ", y);

x = x+y;
y = x-y;
x = x-y;
console.log("after swapping of x = ", x);
console.log ("after swapping of y = ", y);






