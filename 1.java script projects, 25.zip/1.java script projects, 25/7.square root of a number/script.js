// To find the square root of a number in javascript, you can use the built in math.sqrt() method.
// syntax : Math.sqrt(number);

let a = prompt('Enter a number');
let b = Math.sqrt(a);
console.log(b);