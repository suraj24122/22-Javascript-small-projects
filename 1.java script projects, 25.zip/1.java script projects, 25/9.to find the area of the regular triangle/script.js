// to find the area of the regular triangle
// If you know all the slides of a triangle, You can find the area using 'heron's' formula.
// If a, b and c are three sides of a triangle then 
// general formula : s = (a+b+c)/2;

let a = 10;
let b = 5;
let c = 10;

let s = (a+b+c)/2;
let temp = s*(s-a)*(s-b)*(s-c);
let area = Math.sqrt(temp);
console.log ("the sides of a triangle are = ", temp);
