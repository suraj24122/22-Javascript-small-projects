// Convert celsius into fahrenheit

// fahrenheit = celsius * 1.8 + 32;

function convert() {
    let c = document.getElementById("data").value;
    let fahrenheit = (c * 1.8)+32;
    document.getElementById("res").innerText = fahrenheit;
}