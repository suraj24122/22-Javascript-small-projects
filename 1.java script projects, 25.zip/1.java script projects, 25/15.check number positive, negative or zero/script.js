// using Math.sign() method


function check() {
   let value = document.getElementById("data").value;
//    let res = Math.sign(value); 
if(value > 0) {
    res ="positive";
} else if (value < 0) {
    res = "negative";
} else if (value == 0) {
    res = "zero";
}
   document.getElementById("res").innerText = res;
}