// kilometres to miles converter

// 1km = 0.621371
// miles = kilometer * factor

function convert() {
    let kms = document.getElementById("data").value;
    const factor = 0.621371;
    let miles = kms*factor;
    document.getElementById("res").innerText =  "\t therefore the miles are \t" + miles;
}