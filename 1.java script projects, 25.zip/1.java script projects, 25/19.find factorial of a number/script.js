let number = prompt("please enter a number : ");

let fact = 1;
if(number == 0 ){
    console.log(number, "factorial is 1");
} else if(number < 0) {
    console.log(number, "factorial of negative number is not possible");
} else {
    for(let i = 1; i <= number; i++) {
        fact = fact * i;
    }
    console.log("the factorial is", fact);
}