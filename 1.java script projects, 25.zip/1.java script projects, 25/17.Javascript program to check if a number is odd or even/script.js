// JAvascript program to check if number is odd or even

// check using if-else
// check using ternary operator

let x = prompt("Enter a number to find out if it is odd or even");
if(x % 2 == 0 ) {
  console.log(x,"Is the odd number");
} else {
    console.log(x,"Is The even number");
};





















