// using Math.random() method.
// Math.random() returns a random floating-point number ranging from 0 to less than 1

// GET A RANDOM NUMBER BETWEEN A RANGE

// Math.random()* (highestNumber - LowestNumber)+lowestNumber

// generate random number
// let a = Math.random() * (10-1)+1
// console.log("random value between 1 and 10 is ", a);

let x = Math.random();
console.log("Before calculation : ",x);

// x = x*(10 - 1)+1;
x = x*10000;
console.log("After calculation : ",x);
console.log("floor calculation : ",Math.floor(x));





















