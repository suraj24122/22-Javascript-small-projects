function calculateBmi() {
    let height = parseFloat(document.getElementById("height").value);
    let weight = parseFloat(document.getElementById("weight").value);

    if (isNaN(height) || isNaN(weight) || height <= 0 || weight <= 0) {
        document.getElementById("result").innerText = "please enter a valid height and weight values";
        return;
    }

    let bmi = weight / ((height / 100) * (height / 100));
    let bmiCategory;

    if (bmi < 18.5) {
        bmiCategory = "underWeight";
    } else if (bmi < 24.9) {
        bmiCategory = "normalWeight";
    } else if (bmi < 29.9) {
        bmiCategory = "overWeight";
    } else {
        bmiCategory = "Obesity";
    }
    document.getElementById("result").innerText = "Your BMI is : " + bmi.toFixed(2) + bmiCategory;
}